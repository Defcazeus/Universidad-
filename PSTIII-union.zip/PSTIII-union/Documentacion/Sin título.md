orden de trabajo
en cambio de estado existe la redundancia en las opción diagnosticando y reparando mejor solo dejar tres opción lo cual seria, en proceso, finalizando\ por entrar y entregado 