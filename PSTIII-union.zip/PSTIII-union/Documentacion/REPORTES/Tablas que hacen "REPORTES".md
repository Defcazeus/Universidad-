historial_pedido
pedido
pedido_detalle (permiten hacer reportes de los productos mas vendidos, y el ver el comportamiento de compras de los clientes)


historial_servicio
servicio_detalle
servicio_taller()

cita (puede hacer reportes de tasas de cancelación y tal vez alguna demanda de algún cliente)

movimiento_producto(permite hacer el reporte del stock mínimo, la entrada y la salida de lo que sacan del almacén del taller)

factura
factura_detalle(nos van a permitir hacer reportes de las ventas diarias o mensuales, y el calculo de los impuestos)

flujo_caja(aquí se puede hacer reportes de cuanto dinero se gasto o cuanto dinero han gastado o han ganado dentro del taller)


transacción
transacción_detalle(hacen reportes de como fue el método de pago)

historial_vehículo(registro de las reparaciones y mantenimiento que se le hace a cada carra que llega al taller)





