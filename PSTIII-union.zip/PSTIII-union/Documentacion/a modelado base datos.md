

- Agregar tabla con datos modificables de la pagina (nombre de la pagina, colores, fuente, lema, otros datos,)





- usuario registrado 
- guest solo registra su vehiculo y el nombre propietario