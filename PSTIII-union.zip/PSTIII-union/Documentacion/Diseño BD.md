

## Módulo de Usuarios y Seguridad

Gestiona el acceso al sistema y define las capacidades de cada persona.

- **Usuario**: Tabla principal de cuentas con correo y datos de contacto.
- **Rol_usuario**: Define si el usuario es un **Cliente**, **Administrador** o **Gerente** (vía `es_admin`).

## Módulo de Gestión de Vehículos

Registra la información de los autos que ingresan al sistema.

- **Vehiculo**: Almacena datos ( placa, marca) y vincula cada auto a un **Usuario** (dueño).

## Módulo de Taller (Citas y Reparaciones)

Controla la agenda y los trabajos realizados físicamente en el taller.

- **Cat_servicio**: Catálogo maestro de servicios ofrecidos (ej: Cambio de aceite, Frenos) con precios sugeridos.
- **Cita**: Reserva de espacio y tiempo. 
- **Orden_Trabajo_Detalle**: Registro de todo lo realizado durante la reparación (mano de obra extra o insumos específicos).
    

## Módulo de Inventario y Tienda

Gestión de los repuestos y productos físicos que se venden de forma independiente o en el taller.

- **Cat_Producto**: Categorias del inventario (ej: Neumáticos, Filtros, Lubricantes).
- **Producto**: Ficha técnica del repuesto con control de **stock_actual** y**stock_minimo** 
## Módulo de Ventas

Procesa la intención de compra antes de la legalización del pago.

- **Carrito / Carrito_detalle**: Almacena temporalmente los productos o servicios que el usuario selecciona en la web.
- **Pedido / Pedido_detalle**: Aquí se consolidan tanto las compras de la tienda como los resultados de una cita de taller finalizada.

## Módulo de Finanzas y Facturación

Asegura la trazabilidad del dinero y el cumplimiento legal.

- **Transaccion**: Registra el flujo de dinero, método de pago y la referencia de la pasarela bancaria  
- **Factura**: Documento inmutable que contiene el desglose fiscal (subtotal, impuestos) y los datos de facturación del cliente al momento de la compra.

## Módulo Web (CMS)

Permite al administrador modificar el contenido informativo de la página web sin tocar el código.

- **Galeria**: Imágenes y descripciones de trabajos realizados o instalaciones.
- **Informacion_Pagina**: Almacena textos dinámicos como Misión, Visión, Horarios o Contacto mediante una estructura de clave-valor.

